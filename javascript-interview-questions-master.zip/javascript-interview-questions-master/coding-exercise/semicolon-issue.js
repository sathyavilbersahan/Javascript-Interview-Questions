function foo() {
    return
    {
        message: "Hello World"
    };
}
console.log(foo()); //Undefined